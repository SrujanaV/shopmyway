var LanguageEnglish = {
  "ABOUT": "About",
};

var LanguageHindi = {
  "ABOUT": "बारे में",
};
